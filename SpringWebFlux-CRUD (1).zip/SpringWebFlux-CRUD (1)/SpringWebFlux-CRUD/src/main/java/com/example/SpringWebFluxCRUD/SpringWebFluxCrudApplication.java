package com.example.SpringWebFluxCRUD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;

import com.example.SpringWebFluxCRUD.entity.User;

@SpringBootApplication
@EnableR2dbcRepositories
public class SpringWebFluxCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebFluxCrudApplication.class, args);
	}
	
	/*
	 * @Bean public User bean() { return new User(); }
	 */

}
