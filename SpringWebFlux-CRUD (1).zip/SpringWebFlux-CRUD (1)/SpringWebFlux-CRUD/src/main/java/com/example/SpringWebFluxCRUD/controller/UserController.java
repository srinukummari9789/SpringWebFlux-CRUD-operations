package com.example.SpringWebFluxCRUD.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringWebFluxCRUD.entity.User;
import com.example.SpringWebFluxCRUD.repository.UserRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class UserController {
	
	@Autowired
	private UserRepository userRepository;
	
		
	@GetMapping("/users")
	public Flux<User> getAll(){
		return userRepository.findAll();
	}
	
	@PostMapping("/add")
	public Mono<User> addData(@RequestBody User user) {
			return userRepository.save(user);
	}
	
	@DeleteMapping("/delete/{id}")
	public Mono<Void> deleteData(@PathVariable("id") int id){
		return userRepository.deleteById(id);
	}
	
	@PutMapping("/update/{id}")
	public Mono<User> updateDate(@PathVariable("id") int id, @RequestBody User user){
		
		return userRepository.findById(id).flatMap(currentUser -> {
			currentUser.setName(user.getName());
			currentUser.setEmail(user.getEmail());
			return userRepository.save(currentUser);
			});
			
	}

}
